import { readLocalSchema, readSchemaFromRepo, cloneOrPull } from './fetchSchema';
import { summarizeSchema, diffSchemas } from './parseAndDiff';
import { analyzeWithLLM } from './analyzeAndGenerate';
import { writeReport,writeDiff, writeGeneratedTests } from './writeOutputs';
import fs from 'fs';
import {extractAndWriteTests} from "./extractCode";

async function main() {
  const repoUrl = process.env.SCHEMA_REPO_URL;
  const repoLocalPath = 'schemas';
  let latestSchemaStr: string;
  const baselinePath = './schemas/baseline-schema.graphql';

  if (repoUrl) {
    console.log('Cloning or pulling repo...');
    await cloneOrPull(repoUrl, repoLocalPath);
    latestSchemaStr = await readSchemaFromRepo(repoLocalPath, process.env.SCHEMA_PATH || './latest-schema.graphql');
  } else {
    latestSchemaStr = await readLocalSchema('./schemas/latest-schema.graphql');
  }

  const baselineSchema = (await fs.promises.readFile(baselinePath, 'utf8'));
  const baseSummary = summarizeSchema(baselineSchema);
  const latestSummary = summarizeSchema(latestSchemaStr);
  const diff = diffSchemas(baseSummary, latestSummary);

  await writeReport('Machine diff JSON (see JSON file)', diff, 'reports');

  console.log('Calling LLM to analyze diffs and generate tests...');
  const result = await analyzeWithLLM(baseSummary, latestSummary, diff);
//   console.log(result);
// Write report (.md + .json)
  await writeDiff(result.report_text, result, "reports"); // Writting the Json to reports folder

  await extractAndWriteTests(result, "reports"); // Writting the test cases to generated-tests folder

}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

